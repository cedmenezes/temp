
# Explicação

Deixe aqui a sua explicação do que a função `funcao1` faz. Faça uma explicação breve e direta (uma frase ou linha).

Ex: se você acha que é uma função que calcula o fatorial de um parâmetro, basta escrever aqui "Calcula e retorna o fatorial do parâmetro utilizando..."

Sua resposta:
