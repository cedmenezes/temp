// Seu código da funcao1_solucao


