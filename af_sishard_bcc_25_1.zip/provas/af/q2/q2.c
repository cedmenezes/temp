// Leia o HTML ou MD antes de iniciar este exercício!

// inclua libs aqui!

int main(int argc, char *argv[]){

    // SUA RESPOSTA AQUI

    return 0;
}