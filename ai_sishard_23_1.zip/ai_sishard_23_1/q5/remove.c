#include <stdio.h>
#include <stdlib.h>

// Seu código neste arquivo!
char *remove_comentarios(char * funcao){
    // EDITE ESTA FUNÇÃO, INCLUSIVE O RETURN ABAIXO!
    return NULL;    
}

