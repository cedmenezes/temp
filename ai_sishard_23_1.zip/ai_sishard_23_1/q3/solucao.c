#include <stdio.h>

// Implemente aqui uma funcao chamada ex3_solucao

